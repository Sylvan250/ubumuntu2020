<div class="wrapper col5">
  <div id="footer">

    <div id="copyright">
      <center><p class="fl_left">Copyright &copy; 2020 - All Rights Reserved-ubumuntuclinic</p></center>
      
      
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>