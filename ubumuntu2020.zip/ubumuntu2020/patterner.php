<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php include ('heade.php')>

</body>
</html>