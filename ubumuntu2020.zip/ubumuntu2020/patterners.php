<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>


	<style>
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: right;
  width: 180px;

}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: px;
  text-align: center;
}
.tie{
	 max-width: 500px;
  height: 40px;
  margin: 10px;
  padding: 0px;
  background-color: #333;
  position: relative;
  left: 400px;
}
.title{
	max-width: 500px;
  height: 40px;
  margin: 40px;
  padding: 0px;
  background-color:#87ceeb;
  position: relative;
  left: 400px;
}
</style>
	<title></title>
</head>
<body>

  <body style="background-color: white;">
  	
	<?php include('header.php')?>
<h3 class="tie"> UBUMUNTU MEDICAL CLINIC MEDICAL PATTERNERS</h3>

<div class="gallery">

  <a target="_blank" href="images/patterners/rssb.jpg">
    <img src="images/patterners/rssb.jpg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">RSSB(EX RAMA)</div>
</div>

<div class="gallery">
  <a target="_blank" href="images/patterners/sanlam.jpg">
    <img src="images/patterners/sanlam.jpg" alt="Forest" width="600" height="400">
  </a>
  <div class="desc">SANLAM(MEDIPLA)</div>
</div>

<div class="gallery">
  <a target="_blank" href="images/patterners/saham.jpg">
    <img src="images/patterners/saham.jpg" alt="Northern Lights" width="600" height="7 00">
  </a>
  <div class="desc">SAHAM INSUARANCE</div>
</div>

<div class="gallery">
  <a target="_blank" href="images/patterners/britam.jpg">
    <img src="images/patterners/britam.jpg" alt="Northern Lights" width="600" height="700">

  </a>
   <div class="desc">BRITAM INSUARANCE</div>
</div>

  
  <div class="gallery">
  <a target="_blank" href="images/patterners/radiant.jpg">
    <img src="images/patterners/radiant.jpg" alt="Northern Lights" width="800" height="900">
  </a>
  <div class="desc">RADIANT INSUARANCE</div>
</div>
<br><br><br></br>


<h3 class="title"> UBUMUNTU MEDICAL CLINIC MEDICAL SERVICES</h3>



<?php  include('serv_patter.php')  ?>
<br><br/>
<?php include('footer.php') ?>


  </body>




  
  
</html>