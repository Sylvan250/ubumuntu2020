<?php
session_start();
include("headers.php");
include("dbconnection.php");
if(isset($_GET[delid]))
{
	$sql ="DELETE FROM contacts WHERE Contact_Id='$_GET[delid]'";
	$qsql=mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) == 1)
	{
		echo "<script>alert('Message record deleted successfully..');</script>";
	}
}
?>

<div class="wrapper col2">
  <div id="breadcrumb">View sent messages</div>
</div>
<div class="wrapper col4">
  <div id="container">
  
  <section class="container">
<h2>Search Message - <input type="search" class="light-table-filter" data-table="order-table" placeholder="Filtrer" /></h2>
    <table class="order-table">
      <thead>
        <tr>
          <td width="12%" height="40" bgcolor="black">Sender Name</td>
          <td width="11%" bgcolor="black">Sender Email</td>
          <td width="12%"bgcolor="black">Sender Phone</td>
           <td width="12%"bgcolor="black">Subject</td>
            <td width="12%"bgcolor="black">Message</td>
          <td width="3%"bgcolor="red">Action</td>
        </tr>
        </thead>
       <tbody>
       <?php
		$sql ="SELECT * FROM contacts";
		$qsql = mysqli_query($con,$sql);
		while($rs = mysqli_fetch_array($qsql))
		{
        echo "<tr>
          <td>&nbsp;$rs[name]</td>
          <td>&nbsp;$rs[email]</td>
          <td>&nbsp;$rs[mobile]</td>
          <td>&nbsp;$rs[subj]</td>
          <td>&nbsp;$rs[message]</td>
          <td>&nbsp;
		   <a href='viewmessages.php?delid=$rs[Contact_Id]'>Delete</a> </td>
        </tr>";
		}
		?>
      </tbody>
    </table>
    </section>
    <p>&nbsp;</p>
  </div>
</div>
</div>
 <div class="clear"></div>
  </div>
</div>
<?php
include("footers.php");
?>