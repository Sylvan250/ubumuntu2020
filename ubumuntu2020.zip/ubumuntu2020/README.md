# Online-Hospital-Management-System
HMS Project which covers all the aspects of hospital.

Online Hospital Management System:

This project Online Hospital Management System aims at to develop the software that covers all the aspects of management and operations of hospital.

Project Category:    RDBMS

Language(s) to be used: FRONT END: PHP 5.6

RDBMS Software used:    BACK END: MySQL server 5.3

Features:
Patient module
Appointment module
Treatment module
Prescription module
Dashboard module
Billing module
Order module

For updates and reports visit: https://www.studentprojectguide.com/php/online-hospital-management-system/
