<?php
session_start();
include("headers.php");
include("dbconnection.php");
if(isset($_GET[delid]))
{
  $sql ="DELETE FROM doctor_timings WHERE doctor_timings_id='$_GET[delid]'";
  $qsql=mysqli_query($con,$sql);
  if(mysqli_affected_rows($con) == 1)
  {
    echo "<script>alert('Availability record deleted successfully..');</script>";
  }
}
?>

<div class="wrapper col2">
  <div id="breadcrumb">
    <ul>
      <li class="first">View  Doctor Availability Details</li></ul>
  </div>
</div>
<div class="wrapper col4">
  <div id="container">
  
<section class="container">
<h2>Search Doctor - <input type="search" class="light-table-filter" data-table="order-table" placeholder="Filtrer" /></h2>


  <table class="order-table">
      <thead>
        <tr>
          <th>Availability Id</th>
          <th>Doctor Id</th>
          <th>Start Time</th>
          <th>End Time</th>
          <th>Day</th>
           <th>Status</th>
            <th>Action</th>
        </tr>
        </thead> 
        <tbody>
        
          <?php
    $sql ="SELECT * FROM doctor_timings";
    $qsql = mysqli_query($con,$sql);
    while($rs = mysqli_fetch_array($qsql))
    {
        echo "<tr>
          <td>&nbsp;$rs[doctor_timings_id]</td>
          <td>&nbsp;$rs[doctorid]</td>
       <td>&nbsp;$rs[start_time]</td>
       <td>&nbsp;$rs[end_time]</td>
       <td>&nbsp;$rs[available_day]</td>
         <td>&nbsp;$rs[status]</td>
       <td>&nbsp;
        <a href='viewdoctortimings.php?editid=$rs[doctor_timings_id]'>Edit</a> | <a href='viewdoctortimings.php?delid=$rs[doctor_timings_id]'>Delete</a> </td>
        </tr>";
    }
    ?>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </tbody>
    </table>
    </section>
    <h1>&nbsp;</h1>
    <p>&nbsp;</p>
  </div>
</div>
</div>
 <div class="clear"></div>
  </div>
</div>
<?php
include("footers.php");
?>