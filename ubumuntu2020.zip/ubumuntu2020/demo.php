<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Template Name: Corporation
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Corporation</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
</head>
<body id="top">
<div class="wrapper col1" style="background-image: url('images/blue.jfif');">
  <div id="head" style=" height: 220px;">
    <center><a href="index.php"><img src="images/ubumuntu.jpg" width="1000px" height="115px"></a></center>
    
    <div id="topnav">
      <ul>
        <li><a class="active" href="index.php">Home</a></li>
        <li><a href="#">About Ubumuntu</a>
         <ul>
           
<li><a href="aboutus.php">Services and Patterners</a></li>
         </ul>
        </li>
        <li><a href="patient.php">Patient Registration</a></li>
        <li><a href="patient.php">Online Appointment</a></li>
        <li><a href="#">Login</a>
          <ul>
            <li><a href="#">Admin Loggin</a></li>
            <li><a href="#">Doctor Login</a></li>
            <li><a href="#">Patient Login</a></li>
          </ul>
        </li>
        <li class="last"><a href="contactus.php">Message Ubumuntu</a></li>
      </ul>
    </div>
    <div id="search">
      
    </div>
  </div>
</div>
<div class="wrapper col2">
  <div id="gallery">
    <ul>
      <li class="placeholder" style="background-image:url(images/demo/gallery_default.);">Image Holder</li>
      <li><a class="swap" style="background-image:url(images/demo/290x105.gif);" href="#gallery"><strong>Services</strong><span><img src="images/demo/gallery_1.gif" alt="" /></span></a></li>
      <li><a class="swap" style="background-image:url(images/demo/290x105.gif);" href="#gallery"><strong>Products</strong><span><img src="images/demo/gallery_2.gif" alt="" /></span></a></li>
      <li class="last"><a class="swap" style="background-image:url(images/demo/290x105.gif);" href="#gallery"><strong>Company</strong><span><img src="images/demo/gallery_3.gif" alt="" /></span></a></li>
    </ul>
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col4">
  <div id="container">
    <div id="content">
      <h1>WELCOME TO UBUMUNTU MEDICAL CLINIC</h1>
      <p>This is a W3C standards compliant free website template from <a href="http://www.os-templates.com/">OS Templates</a>.</p>
      <p>This template is distributed using a <a href="http://www.os-templates.com/template-terms">Website Template Licence</a>, which allows you to use and modify the template for both personal and commercial use when you keep the provided credit links in the footer.</p>
      <p>For more CSS templates visit <a href="http://www.os-templates.com/">Free Website Templates</a>.</p>
      <p>Lacusenim inte trices lorem anterdum nam sente vivamus quis fauctor mauris. Wisinon vivamus wisis adipis laorem lobortis curabiturpiscingilla dui platea ipsum lacingilla.</p>
      <p>Semalique tor sempus vestibulum libero nibh pretium eget eu elit montes. Sedsemporttis sit intesque felit quis elis et cursuspenatibulum tincidunt non curabitae.</p>
      <div class="homecontent">
        <ul>
          <li>
            <p class="imgholder"><img src="images/demo/286x100.gif" alt="" /></p>
            <h2>Indonectetus facilis leo nibh</h2>
            <p>Nullamlacus dui ipsum conseque loborttis non euisque morbi penas dapibulum orna. Urnaultrices quis curabitur phasellentesque.</p>
            <p>congue magnis vestibulum quismodo nulla et feugiat. Adipisciniapellentum leo ut consequam ris felit elit id nibh sociis malesuada.</p>
            <p class="readmore"><a href="#">Read More &raquo;</a></p>
          </li>
          <li class="last">
            <p class="imgholder"><img src="images/demo/286x100.gif" alt="" /></p>
            <h2>Indonectetus facilis leo nibh</h2>
            <p>Nullamlacus dui ipsum conseque loborttis non euisque morbi penas dapibulum orna.</p>
            <p>Urnaultrices quis curabitur phasellentesque congue magnis vestibulum quismodo nulla et feugiat. Adipisciniapellentum leo ut consequam ris felit elit id nibh sociis malesuada.</p>
            <p class="readmore"><a href="#">Read More &raquo;</a></p>
          </li>
        </ul>
        <div class="clear"></div>
      </div>
      <p>Odiointesque at quat nam nec quis ut feugiat consequet orci liberos. Tempertincidunt sed maecenas eros elerit nullam vest rhoncus diam consequat amet. Diamdisse ligula tincidunt a orci proin auctor lacilis lacilis met vitae.</p>
    </div>
    <div id="column">
      <div id="featured">
        <ul>
          <li>
            <h2>Indonectetus facilis leonib</h2>
            <p class="imgholder"><img src="images/demo/240x90.gif" alt="" /></p>
            <p>Nullamlacus dui ipsum conseque loborttis non euisque morbi penas dapibulum orna. Urnaultrices quis curabitur phasellentesque congue magnis vestibulum quismodo nulla et feugiat. Adipisciniapellentum leo ut consequam ris felit elit id nibh sociis malesuada.</p>
            <p class="more"><a href="#">Read More &raquo;</a></p>
          </li>
        </ul>
      </div>
      <div class="holder">
        <div class="imgholder"><img src="images/demo/290x100.gif" alt="" /></div>
        <p>Nullamlacus dui ipsum conseque loborttis non euisque morbi penas dapibulum orna.</p>
        <p class="readmore"><a href="#">Read More &raquo;</a></p>
      </div>
    </div>
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col5">
  <div id="footer">
    <div id="contactform">
      <h2>CONTACT OUR TEAM</h2>
      <form action="index.php" method="post">
        <fieldset>
          <legend>Contact Form</legend>
          <label for="fullname">Name:
            <input id="fullname" name="t1" type="text" value="" />
          </label>
          <label for="emailaddress" class="margin">Email:
            <input id="emailaddress" name="t2" type="text" value="" />
          </label>
          <label for="mobile">Telephone:
            <input id="phone" name="t3" type="text" value="" />
          </label>
          <label for="subject" class="margin">Subject:
            <input id="subject" name="t4" type="text" value="" />
          </label>
          <label for="message">Message:<br />
            <textarea id="message" name="t5" cols="40" rows="4"></textarea>
          </label>
          <p>
            <input id="submitform" name="submitform" type="submit" value="Submit" />
            &nbsp;
            <input id="resetform" name="resetform" type="reset" value="Reset" />
          </p>
        </fieldset>
      </form>
      <!---Sending message using form-->
      <?php
      error_reporting(0);
      include_once 'dbconnection.php';
    if(isset($_POST["submitform"])) 
    {
      
            

          $s="insert into contacts(name,email,mobile,subj,message) values('" . $_POST["t1"] ."','" . $_POST["t2"] . "','" . $_POST["t3"] . "','" . $_POST["t4"]   ."','" . $_POST["t5"] . "')";
          
          
      $q=mysqli_query($con,$s);
      mysqli_close($con);
      if($q>0)
      {
      echo "<script>alert('Record Save');</script>";
      }
      else
      {echo "<script>alert('Saving Record Failed');</script>";
      }
        
        } 
      

    ?> 
    </div>
    <!-- End Contact Form -->
    <div id="compdetails">
      <div id="officialdetails">
        <h2>OUR SERVICES</h2>
        <ul>
          <li>OBSTETRIC </li>
          <li>GENERAL MEDECINE &amp; LABORATORY</li>
          <li>PEDIATRICS</li>
          <li class="last">ECHOGRAPHY/ULTRASONIC</li>
        </ul>
        <h2>Follow Us</h2>
        <p> <a href="#" class="fa fa-facebook"></a> |<a href="#" class="fa fa-twitter" style="background-color: #33DAFF;"></a>|<a href="#" class="fa fa-instagram" style="background-color: #33DAFF;"><a href="#" class="fa fa-whatsapp" style="background-color: #33DAFF;"></a>|<a href="#" class="fa fa-linkdin" style="background-color: #33DAFF;"></a></p>
      </div>
      <div id="contactdetails">
        <h2>Our CONTACT DETAILS Details !</h2>
        <ul>
          <li>UBUMUNTU MEDICAL CLINIC</li>
          <li>KICUKIRO &amp; KK490 st</li>
          <li>KIGALI</li>
          <li></li>
          <li>Tel1:+250788306512</li>
          <li>Tel2: +250788426779</li>
          <li>Email: info@ubumuntuclinic.rw</li>
          <li class="last">LinkedIn: <a href="#">Ubumuntu clinic</a></li>
        </ul>
      </div>
      <div class="clear"></div>
    </div>
    <!-- End Company Details -->
    <div id="copyright">
      <p class="fl_left">Copyright &copy; 2020 - All Rights Reserved - <a href="#">ubumuntuclinic</a></p>
      
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>