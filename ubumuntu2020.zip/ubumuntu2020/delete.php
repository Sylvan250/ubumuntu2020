<?php
//including the database connection file
include("dbconnection.php");

//getting id of the data from url
$id = $_GET['doctor_timings_id'];

//deleting the row from table
$result = mysqli_query($con, "DELETE FROM doctotr_timings WHERE doctor_timings_id='$_GET[doctor_timings_id]'");

//redirecting to the display page (index.php in our case)
//header("Location:viewemployee.php");
?>

