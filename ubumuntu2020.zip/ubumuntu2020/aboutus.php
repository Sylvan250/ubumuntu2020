 <!DOCTYPE html>
 <html>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <head>
  <style type="">
    body{
   width: 100%;
    border: none;
    margin: auto;
    background-color: #808080;
}
  </style>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
  <meta charset="utf-8" http-equiv="content-type" content="text/html" >
  <title>Home</title>
  <link rel="icon" type="image/jpg" href="images/LOGO.jpg">

 </head>
 <body style="width: 100%;
    border: none;
    margin: auto;
    background-image: url(images/hdd.jpg); background-repeat: no-repeat;">
  <div id="wrapper">
    <div id="barnner">
      
    </div>
    <?php include('header.php') ?>

  
  
  

      
      
    </div>
  </li>
</ul>
      
    </nav>
    <div id="content_area" style="width: 70%;
    border: none;
    margin: auto;
    background-color: #99ccff; color: black;">
      <h3 style="position: relative;left: 50px;">ABOUT UBUMUNTU MEDICAL CLINIC</h3>
      <dir class="welcome" style="position: relative; left: 11px;">
        
        <p>  The goal of <b>UBUMUNTU MEDICAL CLINIC</b>
   is to improve the efficiency of the health by caring about patients through <b>Online Doctor Appointment</b>  reducing the overall time and cost used to create documents and retrieve information of Patients.Welcome to every patient as we have great collaboration with patternerssuch as:SAHAM,SANLAM,RSSB,BRITAM,....
.</p>
      <p>The main feature of E-Knowledge in Doctor appointment system is to provide the browser to get appointments from a doctor through internet instead of going there and fixing an appointment..</p>
      <p> Everyone needs to have Medical attention at any time. So we allow every user to register freely at any time..</p>
      <p>Doctor appointment System maintains patient�s prescriptions so that their medical details are always available in Internet, which will be more convenient for the patients. This will be more comfortable for the patient..</p>

      </div><br/>
      <ul>
          
          
        </ul><br>
      <center><h4 style="color: black">UBUMUNTU CLINIC SERVICES</h4></center>
      
      <?php include('Services.php')?>
    </div>
    <div id="sidebar">
      
    </div>
    <footer>
      
  

            <?php include('footer.php')?>
            
      <center><p>All rights reserved</p></center>
    </footer>
  </div>
 
 </body>
 </html>