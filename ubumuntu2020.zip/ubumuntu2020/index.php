<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Template Name: Corporation
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <style>
  .fa {
  padding: 10px;
  font-size: 30px;
  width: 30px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
  border-radius: 40%;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-twitter {
  background: blue;
  background-color: blue
  color: white;
}

.fa-instagram {
  background: #125688;
  color: red;
}


.fa-skype {
  background: #00aff0;
  color: white;
}



.fa-yahoo {
  background: #430297;
  color: white;
}
.fa-phone{
  background-color:green;
}



</style>
 
<!-- Start Bootstrap Carousel HEAD section -->
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<!-- End Bootstrap Carousel HEAD section -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>Home</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
</head>
<body id="top">
<div class="wrapper col1" style="background-image: url('images/blue.jfif');">
  <div id="head" style=" height: 220px;">
    <center><a href="index.php"><img src="images/ubumuntu.jpg" width="1000px" height="115px"></a></center>
    
    <div id="topnav">
      <ul>
        <li><a class="active" href="index.php">Home</a></li>
        <li><a href="#">About Ubumuntu</a>
         <ul>
           
<li><a href="aboutus.php">Services&Patterners</a></li>
         </ul>
        </li>
        <li><a href="patient.php">Patient Registration</a></li>
        <li><a href="patient.php">Online Appointment</a></li>
        <li><a href="#">Login</a>
          <ul>
            <li><a href="adminlogin.php">Admin Login</a></li>
            <li><a href="doctorlogin.php">Doctor Login</a></li>
            <li><a href="patientlogin.php">Patient Login</a></li>
          </ul>
        </li>
        <li class="last"><a href="index.php">Message Ubumuntu</a></li>
      </ul>
    </div>
    <div id="search">
      
    </div>
  </div>
</div>
<div class="wrapper col2">
  <div id="gallery">
    <div class="w3-content w3-section" style="max-width:500px;position: relative;right:10px;">
  <b>UBUMUNTU MEDICAL CLINIC PHOTOS</b>
  <img class="mySlides w3-animate-fading" src="images/services/medecine.jpg" style="width:170%">
  <img class="mySlides w3-animate-fading" src="images/services/laboratory.jpg" style="width:170%">
  <img class="mySlides w3-animate-fading" src="images/services/obstetric.jpg" style="width:170%">
  <img class="mySlides w3-animate-fading" src="images/services/planing.jpg" style="width:170%">
</div>
<script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 6000);    
}
</script>



<!-- End Bootstrap Carousel BODY section -->
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col4">
  <div id="container">
    <div id="content">
      <b>WELCOME TO UBUMUNTU MEDICAL CLINIC</b>
      <p>This is an official website of UBUMMUNTU MEDICAL CLINIC <a href="http://www.ubumuntuclinic.rw/">ubumuntuclinic.rw</a>.</p>
      <p>The patient has to register or get online appointment <a href="patient.php">and know whether the doctor is available or not</a>, which allows you to save your time and money spent on travelling. the patient can view his recors everywhere on the world.</p>
      <p>Here at <b>UBUMUNTU MEDICAL CLINI</b>  using <a href="http://www.os-templates.com/">online doctor appointment is free and easy to use.</a>.</p>
      <p>It is possible that you can meet inconvinience via our online services contact us for <a href="contactus.php">help</a>.</p>
      <p>you will be replied and helped as quick as possible.</p>
      <div class="homecontent">
        <ul>
          <li>
            <p class="imgholder" style="border: solid 1px cyan;"><a href="patientlogin.php"><img src="images/login.jpg" width="286" height="100px"></a></p>
            <h2 style="color: blue;">Login for existing user</h2>
            <p>For existing patient you are asked to login by clicking above image. After login you can view your Clinic records..</p>
            <p class="readmore" style="position: relative;right: 115px; color: blue;"><a href="#" style="color: blue;">UBUMUNTU  PATTERNERS</a></p>
            <ul>
              <li>SAHAM</li>

        <li>RSSB(EX RAMA)</li>
        <li>SANLAM</li>
        
        <li>BRITAM</li>
        <li>RADIANT</li>

            </ul>
          </li>
          <li class="last">
            <p class="imgholder" style="border:  solid 1px cyan;"><a href="patient.php"><img src="images/appointment.png" alt="" width="286px" height="100px"></a> </p>
            <h2 style=" color: blue;">Book Appointment from now!</h2>
            <p>Maybe that you're new at <b>UBUMUNTU MEDICAL CLINIC</b>  System no matter if you're not registered you can book an appointment with our doctors.</p>
            <p></p>
            <p class="readmore" style="position: relative;right: 140px; color: blue"><a href="#" style="color: blue;">UBUMUNTU SERVICES  </a></p>
            <ul>
              

        <li>GENERAL MEDECINE</li>
        <li>OBSTETRICS</li>
        <li>PEDIATRICS</l>
        <li>ECHOGRAPHY/ULTRASOUND</li>
        <li>MINOR SURGERY</li>
        <li>LABORATORY</li>
        <li>FAMILY PLANNING</li>

            </ul>
          </li>
        </ul>
        <div class="clear"></div>
      </div>
      <p>.</p>
    </div>
    <div id="column">
      <div id="featured">
        <ul>
          <li>
            <h2>Doctor Message</h2>
            <p class="img"><img src="images/header_img.jpg" alt="" width="200px" /></p>
            <p>UBUMUNTU MEDICAL CLINIC is wecoming you with your sickness, accident doctor test  in our rapid results laboratory.</p>
            <p class="more"><a href="#">Read More &raquo;</a></p>
          </li>
        </ul>
      </div>
      <div class="holder">
        <div class="imr"><img src="images/fina.jpg" alt="" width="200px" /></div>
        <p> Customer care&nbsp;Phone:0785087298</p>
        <p class="readmore"><a href="#"> &raquo;</a></p>
      </div>
    </div>
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col5">
  <div id="footer">
    <div id="contactform">
      <h2>CONTACT OUR TEAM</h2>
      <form action="" method="post">
        <fieldset>
          <legend>Contact Form</legend>
          <label for="fullname">Name:
            <input id="fullname" name="t1" type="text" value="" />
          </label>
          <label for="emailaddress" class="margin">Email:
            <input id="emailaddress" name="t2" type="text" value="" />
          </label>
          <label for="mobile">Telephone:
            <input id="phone" name="t3" type="text" value="" required="" />
          </label>
          <label for="subject" class="margin">Subject:
            <input id="subject" name="t4" type="text" value="" />
          </label>
          <label for="message">Message:<br />
            <textarea id="message" name="t5" cols="40" rows="4" required="this field is required"></textarea>
          </label>
          <p>
            <input id="submitform" name="submitform" type="submit" value="Submit" />
            &nbsp;
            <input id="resetform" name="resetform" type="reset" value="Reset" />
          </p>
        </fieldset>
      </form>
      <!---Sending message using form-->
      <?php
      error_reporting(0);
      include_once 'dbconnection.php';
    if(isset($_POST["submitform"])) 
    {
      
            

          $s="insert into contacts(name,email,mobile,subj,message) values('" . $_POST["t1"] ."','" . $_POST["t2"] . "','" . $_POST["t3"] . "','" . $_POST["t4"]   ."','" . $_POST["t5"] . "')";
          
          
      $q=mysqli_query($con,$s);
      mysqli_close($con);
      if($q)
      {
         header("location:injdex.php");
      echo "<script>alert('Message has been sent successfully ok......');</script>";
     
      }
      else
      {echo "<script>alert('Sending Failed......');</script>";
      }
        
        } 
      

    ?> 
    </div>
    <!-- End Contact Form -->
    <div id="compdetails">
      <div id="officialdetails">
        <h2>OUR MISSIONS</h2>
        <ul>
          <li>CUSTOMERCARE </li>
          <li>INTEGRITY </li>
          <li>EXELENCE </li>
          <li class="last">AUTOMATED SERVICES</li>
        </ul>
        <h4>Stay Connected with us</h4>
        <p> <a href="#" class="fa fa-facebook" style="font-size: 30px;"></a> |<a href="#" class="fa fa-twitter" style="font-size: 30px;"></a>|<a href="#" class="fa fa-instagram" style="font-size:30px;"><a></a></p>
      </div>
      <div id="contactdetails" style="position: relative; left: 180px;">
        <h2> CONTACT  DETAILS !</h2>
        <ul>
          <li>UBUMUNTU MEDICAL CLINIC</li>
          <li>KICUKIRO &amp; KK490 st</li>
          <li>KIGALI</li>
        
          <li>Tel1:+250788306512</li>
          <li>Tel2: +250788426779</li>
          <li>Email: info@ubumuntuclinic.rw</li>
          <li class="last">LinkedIn: <a href="#">Ubumuntu clinic</a></li>
        </ul>
      </div>
      <div class="clear"></div>
    </div>
    <!-- End Company Details -->
  
    <div id="copyright">
      <hr>
      <p class="fl_left"><center>Copyright &copy; 2020 - All Rights Reserved - <a href="#">ubumuntuclinic</a></center></p>
      
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>